# Simple Project

This project is used to verify SecureZip export behaviour.
